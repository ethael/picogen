<!-- title: Home -->

# Welcome to Picogen

This is the interactive documentation for Picogen - a minimalistic static site generator written in a single Python file with less than 500 lines of code.

## What is Picogen?

Picogen is a static site generator designed with simplicity and readability in mind. Unlike Hugo or Jekyll, you can read and understand the entire codebase in an afternoon. Despite its small size, it's fully featured with support for taxonomies, RSS feeds, sitemaps, and dual-protocol generation (HTML and Gemini).

## Features

- **Single file implementation** - Less than 500 lines of Python
- **Dual protocol** - Generate HTML and Gemini from same Markdown source
- **Flexible taxonomy system** - Tags, categories, series, or create your own
- **Automatic RSS/Atom feeds** - Keep readers subscribed
- **Sitemap generation** - SEO-friendly out of the box
- **Template inheritance** - DRY templating with simple syntax
- **No dependencies hell** - Just a few small Python packages

## Documentation

{{ blog_recent-posts_ }}

## Getting Started

1. Clone the repository
2. Run `python picogen.py --init`
3. Generate your site with `python picogen.py --generate http gemini`
4. Serve locally with `python picogen.py --serve http`

That's it! Read the documentation posts above to learn everything about Picogen.

## Why Picogen?

- **Hackable** - Understand and modify the entire codebase
- **Minimal** - No bloat, no complexity, just what you need
- **Fast** - Generates sites in seconds
- **Portable** - One Python file, runs anywhere
- **Free** - MIT licensed open source

Visit the [Projects](/projects/) page to see what you can build with Picogen.
