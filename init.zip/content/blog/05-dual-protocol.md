<!-- date: 2024-01-05 -->
<!-- title: Dual Protocol Support - HTML and Gemini -->
<!-- blog -->
<!-- tags: Gemini, Protocol, Tutorial -->
<!-- series: Documentation -->
<!-- readtime: 5 -->

One of Picogen's unique features is generating both HTML websites and Gemini capsules from the same Markdown source. This guide explains how it works.

## What is Gemini?

Gemini is a lightweight internet protocol designed as an alternative to HTTP. It emphasizes:

- Privacy and simplicity
- No tracking, cookies, or JavaScript
- Clean, fast text-based content
- Minimal markup language (Gemtext)

Think of it as a modern successor to Gopher, designed for human-focused content without web bloat.

## Generating Both Protocols

Generate for both protocols in one command:

```bash
python picogen.py --generate http gemini
```

This creates:
- `target/html/` - Full HTML website
- `target/gmi/` - Gemini capsule

## Directory Structure

Separate templates and static files per protocol:

```
templates/
  html/           HTML templates
    page.html
    post_page.html
  gmi/            Gemini templates
    page.gmi
    post_page.gmi

static/
  html/           CSS, images for web
    style.css
    avatar.jpg
  gmi/            Gemini-specific files
    README.txt

content/
  blog/
    post.md       Converts to both!
  page.html       HTML-only
  page.gmi        Gemini-only
```

## Markdown Conversion

Markdown files (`.md`) are automatically converted:

- **To HTML**: Uses CommonMark for full HTML output
- **To Gemini**: Uses md2gemini for Gemtext format

The same content file generates both versions!

## Protocol-Specific Files

Create protocol-specific content when needed:

- `about.html` - Only generates HTML version
- `about.gmi` - Only generates Gemini version
- `about.md` - Generates both versions

## Template Differences

HTML templates use full HTML:

```html
<!DOCTYPE html>
<html>
  <head>
    <title>{{ title }}</title>
    <link rel="stylesheet" href="{{ base_path }}style.css"/>
  </head>
  <body>
    <nav>...</nav>
    {{ body }}
  </body>
</html>
```

Gemini templates use simple Gemtext:

```
{{ title }} - {{ subtitle }}

=> {{ base_path }} home
=> {{ base_path }}blog/ blog
=> {{ base_path }}blog/feed.xml atom feed

{{ body }}

{{ current_year }} {{ author }}
```

## URL Scheme Variables

Use `{{ scheme }}` for protocol-appropriate URLs:

- HTTP: `http` or `https` (based on ssl_enabled)
- Gemini: Always `gemini`

Example in feed template:
```xml
<link>{{ scheme }}://{{ domain }}{{ base_path }}</link>
```

## Serving Locally

Test each protocol separately:

**HTTP:**
```bash
python picogen.py --serve http
# Visit http://localhost:8000
```

**Gemini:**
```bash
python picogen.py --serve gemini
# Visit gemini://localhost:8000 with Gemini browser
```

## Gemini Browsers

To view your Gemini capsule, try:

- **Lagrange** - Modern graphical browser
- **Amfora** - Terminal-based browser
- **Kristall** - Qt-based desktop browser
- **Elpher** - Emacs plugin

## Best Practices

1. **Write in Markdown** - Converts cleanly to both formats
2. **Keep templates simple** - Gemini has minimal formatting
3. **Test both outputs** - Ensure content works in each protocol
4. **Use semantic HTML** - Converts better to Gemtext
5. **Provide both formats** - Let users choose their experience

## Why Dual Protocol?

- **Accessibility** - Reach users on both web and Gemini
- **Future-proofing** - Not locked into one platform
- **Content-focused** - Forces clean, readable writing
- **Privacy-conscious** - Gemini respects user privacy
- **Single source** - Maintain content once

Dual protocol support makes Picogen unique - embrace both the modern web and the simple, privacy-focused Gemini space!
