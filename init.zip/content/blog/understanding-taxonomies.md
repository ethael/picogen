<!-- date: 2024-01-20 -->
<!-- title: Understanding Taxonomies in Picogen -->
<!-- blog: -->
<!-- tags: Tutorial, Advanced -->
<!-- series: Getting Started Guide -->
<!-- readtime: 4 -->

One of Picogen's most powerful features is its flexible taxonomy system. Let me explain how it works and why it's useful.

### What Are Taxonomies?

Taxonomies are simply ways to categorize and organize your content. Common examples include tags, categories, and series. In Picogen, you can define any taxonomy you want in the configuration file.

### How to Use Taxonomies

Adding a taxonomy to your post is straightforward. Just include it in the metadata section at the top of your Markdown file:

```
<!-- tags: Tutorial, Advanced -->
<!-- series: Getting Started -->
```

### Automatic Index Generation

Here's where it gets interesting. Picogen can automatically generate index pages for your taxonomies. Want a page listing all posts with the "Tutorial" tag? Picogen creates it for you.

You can configure whether these indexes are:
- Generated as files
- Generated as variables to embed in templates
- Sorted by date or name
- Limited to a specific number of items

### Flexible Configuration

The taxonomy system is configured in `config.json`. You can define multiple taxonomies, each with its own indexes and templates. This flexibility means you can organize your content exactly how you want.

This makes Picogen suitable for blogs, documentation sites, wikis, and more.
