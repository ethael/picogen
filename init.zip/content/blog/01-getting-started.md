<!-- date: 2024-01-01 -->
<!-- title: Getting Started with Picogen -->
<!-- blog: -->
<!-- tags: Tutorial, Getting Started -->
<!-- series: Documentation -->
<!-- readtime: 5 -->

Welcome to Picogen - a minimalistic static site generator that fits in a single Python file with less than 500 lines of code. This guide will help you get started quickly.

## What is Picogen?

Picogen is a static site generator designed with simplicity and readability in mind. Unlike Hugo or Jekyll with their complex codebases, Picogen's entire implementation can be read and understood in an afternoon. Despite its small size, it's fully featured with support for:

- Dual protocol generation (HTML and Gemini)
- Flexible taxonomy system (tags, categories, series, etc.)
- Automatic RSS/Atom feeds
- Sitemap generation
- Template inheritance
- Markdown to HTML/Gemini conversion

## Quick Start

After cloning the repository and installing dependencies, initialize a demo site:

```bash
python picogen.py --init
```

This creates the complete directory structure with example content, templates, and configuration.

Generate your site for both protocols:

```bash
python picogen.py --generate http gemini
```

Serve it locally to preview:

```bash
python picogen.py --serve http
# Visit http://localhost:8000
```

## Directory Structure

After initialization, you'll have:

- `content/` - Your markdown posts and pages
- `templates/html/` and `templates/gmi/` - Templates for each protocol
- `static/html/` and `static/gmi/` - Static files (CSS, images)
- `config.json` - Site configuration
- `target/` - Generated output (created during build)

## Your First Post

Create a new markdown file in `content/blog/`:

```markdown
<!-- date: 2024-01-15 -->
<!-- title: My First Post -->
<!-- blog: -->
<!-- tags: Tutorial -->
<!-- readtime: 3 -->

# My First Post

This is my first blog post with Picogen!
```

The HTML comments at the top are metadata. The rest is your content in Markdown format.

Run `--generate` again and your post will appear in the blog index.

## Next Steps

Now that you have Picogen running, explore:

- The taxonomy system for organizing content
- Template customization and inheritance
- Configuration options in config.json
- RSS feed and sitemap generation

Check out the other documentation posts in this series to learn more!
