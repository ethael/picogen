<!-- date: 2024-01-10 -->
<!-- title: Tips, Tricks, and Best Practices -->
<!-- blog: -->
<!-- tags: Tips, Best Practices -->
<!-- series: Documentation -->
<!-- readtime: 6 -->

After exploring Picogen's features, here are practical tips and best practices for building better sites faster.

## Template Organization

### Naming Conventions

**Multi-word templates:**
Use hyphens: `blog-index.html`, `tag-list-item.html`

**Template inheritance:**
Use underscore: `post_page.html` inherits from `page.html`

**Never mix:** Don't use hyphens AND underscores in same name for different purposes.

### Base Templates

Create a solid foundation:

**page.html** - Base for all pages
```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>{{ title }} - {{ subtitle }}</title>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="{{ base_path }}style.css"/>
  </head>
  <body>
    <nav>{{ site_navigation }}</nav>
    {{ body }}
    <footer>{{ site_footer }}</footer>
  </body>
</html>
```

All other templates inherit from this.

### Template Reuse

Don't duplicate! Create reusable pieces:

- `page.html` - Base layout
- `post_page.html` - Blog posts
- `project_page.html` - Project pages
- `list_page.html` - Index pages

## Content Organization

### Directory Structure

Organize by content type:

```
content/
  blog/
    2024-01-post.md
    2024-02-post.md
  projects/
    project-one.md
    project-two.md
  pages/
    about.md
    contact.md
  index.md
```

### File Naming

**Posts:** Use date prefix: `2024-01-15-post-title.md`
- Keeps chronological order
- Easy to find posts
- Shows age at glance

**Pages:** Use descriptive names: `about.md`, `portfolio.md`

**Avoid:** Spaces, special characters, uppercase

### Metadata Consistency

Create metadata templates for yourself:

**Blog post template:**
```markdown
<!-- date: YYYY-MM-DD -->
<!-- title:  -->
<!-- blog: -->
<!-- tags:  -->
<!-- series:  -->
<!-- readtime:  -->

Content here...
```

Save as snippet or file template.

## Configuration Management

### Start Simple

Begin with minimal config:
```json
{
  "domain": "example.com",
  "ssl_enabled": "false",
  "base_path": "/",
  "subtitle": "My Site",
  "author": "Your Name",
  "default_template": "page",
  "taxonomies": [
    {
      "id": "blog",
      "title": "Blog",
      "document_template": "post",
      "value_posts_indexes": [
        {
          "id": "index",
          "template": "blog-index",
          "item_template": "blog-index-item",
          "output_type": "file"
        }
      ]
    }
  ]
}
```

Add features as needed.

### Add Features Incrementally

1. Start with blog taxonomy
2. Add tags when you have 5+ posts
3. Add series for multi-part content
4. Add RSS feed when you have readers
5. Add sitemap before promoting site

Test each addition before moving to next.

## Development Workflow

### Rapid Iteration

```bash
# Terminal 1: Auto-rebuild on changes
while true; do
  python picogen.py --generate http
  sleep 2
done

# Terminal 2: Local server
python picogen.py --serve http
```

Or use entr:
```bash
ls -d content/* templates/* config.json | entr python picogen.py --generate http
```

### Quick Testing

```bash
# Rebuild and open browser
python picogen.py --generate http && \
  python picogen.py --serve http &
  sleep 1 && xdg-open http://localhost:8000
```

### Version Control

**Always commit:**
- content/
- templates/
- static/
- config.json
- README.md

**Never commit:**
- target/
- *.pyc
- __pycache__/
- init.zip (except in repo root)

**.gitignore:**
```
target/
__pycache__/
*.pyc
.DS_Store
views.txt
```

## Writing Tips

### First Paragraph Matters

The first paragraph becomes your summary in:
- Feed readers
- Index pages
- Search results
- Social shares

Make it count! Explain what the post covers.

### Markdown Best Practices

**Use semantic markup:**
```markdown
# Main Title (H1)
## Section (H2)
### Subsection (H3)

**Bold** for emphasis
*Italic* for terms

- Bullet lists
- For readability

1. Numbered lists
2. For sequences
```

**Avoid HTML in Markdown:**
Gemini conversion breaks with raw HTML.

### Reading Time

Estimate honestly:
- 200-250 words per minute
- Count words: `wc -w content/blog/post.md`
- Divide by 225
- Round up

### Tags Strategy

**Good tags:**
- Specific but not too narrow
- Consistent naming
- 2-5 tags per post
- Mix broad and specific

**Examples:**
- ✅ Python, Tutorial, Web Development
- ❌ python, PYTHON, py, python3

## Performance

### Image Optimization

Before adding images:
```bash
# Resize
convert large.jpg -resize 1200x1200\> optimized.jpg

# Compress
jpegoptim --max=85 optimized.jpg
```

### CSS Optimization

Keep CSS minimal:
- Use system fonts
- Minimize colors
- Avoid frameworks
- One CSS file

### Build Performance

Large sites (100+ posts):
- Use specific index limits
- Generate only needed indexes
- Consider splitting taxonomies

## Testing Checklist

Before deploying:

**Generated files:**
- [ ] All posts present in blog index
- [ ] Tag pages generated
- [ ] RSS feed validates
- [ ] Sitemap at root
- [ ] All images load

**Links:**
- [ ] Internal links work
- [ ] External links work
- [ ] Base path correct
- [ ] Feed link in header

**Content:**
- [ ] No draft posts visible
- [ ] Dates correct
- [ ] Summaries make sense
- [ ] Code blocks render properly

**Protocols:**
- [ ] HTML version works
- [ ] Gemini version works
- [ ] Both have feed

## Troubleshooting Guide

### Post Not Appearing

1. Check for `<!-- draft: -->` field
2. Verify file extension (.md, .html, .gmi)
3. Ensure taxonomy in config
4. Check console for errors

### Template Not Found

1. Verify template file exists
2. Check spelling in config
3. Look for underscore/hyphen confusion
4. Ensure parent template exists (for inheritance)

### Variables Empty

1. Check variable name spelling
2. Verify index `output_type` is "variable"
3. Look at console for generated variable names
4. Check index is associated with taxonomy

### Build Errors

1. Validate config.json syntax
2. Check all templates have matching item_templates
3. Verify Python dependencies installed
4. Read error message carefully

## Deployment Checklist

Before first deploy:

- [ ] Update domain in config.json
- [ ] Set ssl_enabled correctly
- [ ] Update author and subtitle
- [ ] Remove example content
- [ ] Test full build
- [ ] Validate RSS feed
- [ ] Validate sitemap
- [ ] Check robots.txt

## Learning Path

1. **Day 1:** Run --init, explore generated site
2. **Day 2:** Create first post, understand metadata
3. **Day 3:** Modify templates, learn variables
4. **Day 4:** Add tags taxonomy
5. **Day 5:** Configure RSS feed
6. **Week 2:** Customize templates fully
7. **Week 3:** Deploy to production
8. **Week 4:** Add Gemini protocol

## Resources

**Validation:**
- Feed: https://validator.w3.org/feed/
- Sitemap: https://www.xml-sitemaps.com/validate-xml-sitemap.html
- HTML: https://validator.w3.org/

**Markdown:**
- CommonMark spec: https://commonmark.org/
- Markdown guide: https://www.markdownguide.org/

**Gemini:**
- Gemini protocol: https://gemini.circumlunar.space/
- Gemtext syntax: https://gemini.circumlunar.space/docs/gemtext.gmi

## Common Patterns

### Recent Posts Sidebar

Config:
```json
{
  "id": "recent",
  "limit": "5",
  "output_type": "variable"
}
```

Template:
```html
<aside>
  <h3>Recent Posts</h3>
  {{ blog_recent_ }}
</aside>
```

### Related Posts

Use same taxonomy (series/tags) to group related content.

### Archive Page

Create index ordered by date with all posts.

### Search

Static sites can't search natively, but you can:
- Use DuckDuckGo: Add `site:yourdomain.com search term`
- Add Google Custom Search
- Use Pagefind or similar static search

With these tips, you'll build better Picogen sites faster. Happy generating!
