<!-- date: 2024-01-04 -->
<!-- title: Complete Configuration Guide -->
<!-- blog -->
<!-- tags: Configuration, Reference -->
<!-- series: Documentation -->
<!-- readtime: 8 -->

The `config.json` file controls every aspect of your Picogen site. This guide explains all available configuration options.

## Global Settings

```json
{
  "generator_name": "Picogen",
  "generator_version": "0.2",
  "generator_url": "https://github.com/ethael/picogen",
  "domain": "example.com",
  "ssl_enabled": "false",
  "base_path": "/",
  "subtitle": "Your Site Tagline",
  "author": "Your Name",
  "default_template": "page",
  "custom_date_format": "%B %d, %Y"
}
```

### Field Descriptions

**domain** - Your site's domain without protocol
- Used in RSS feeds and sitemaps
- Example: `myblog.com`

**ssl_enabled** - Whether your site uses HTTPS
- Values: `"true"` or `"false"` (string, not boolean)
- Affects generated URLs in feeds

**base_path** - Base path for all URLs
- Usually `/` for root deployment
- Use `/blog/` if site is in subdirectory

**subtitle** - Site tagline or description
- Appears in page titles and feeds
- Keep it concise

**author** - Default author name
- Used in templates and feeds
- Can be overridden per-post

**default_template** - Template for pages without explicit template
- Should always exist in templates directory
- Usually `page` for generic pages

**custom_date_format** - Python strftime format string
- Optional custom date formatting
- Example: `%B %d, %Y` → "January 15, 2024"
- See Python strftime docs for format codes

**page_views_file** - Path to page views data file
- Optional analytics integration
- Format: `path:count` per line
- Example: `/blog/post-name:150`

## Taxonomy Configuration

Taxonomies are defined in the `taxonomies` array:

```json
{
  "taxonomies": [
    {
      "id": "blog",
      "title": "Blog",
      "document_template": "post",
      "value_posts_indexes": [...],
      "value_indexes": [...]
    }
  ]
}
```

### Taxonomy Fields

**id** - Unique identifier (required)
- Used in file headers and variable names
- Should be lowercase, no spaces
- Examples: `blog`, `tags`, `series`

**title** - Display title (required)
- Human-readable name
- Used in page titles and navigation

**document_template** - Default template for documents
- Applied to all posts with this taxonomy
- Example: Blog posts use "post" template

## Value Posts Indexes

Configure how post lists are generated:

```json
{
  "id": "index",
  "template": "blog-index",
  "item_template": "blog-index-item",
  "order_by": "date",
  "order_direction": "desc",
  "limit": "10",
  "output_type": "file",
  "output_suffix": "xml",
  "output_path": "sitemap.xml"
}
```

**id** - Index identifier (required)
- Used in filenames and variable names

**template** - Wrapper template (required)
- Contains index structure and `{{ body }}`

**item_template** - Individual post template (required)
- Repeated for each post

**order_by** - Sort field (optional, default: date)
- Options: `date`, `title`, or any metadata field

**order_direction** - Sort order (optional, default: desc)
- `asc` - Ascending (oldest/A-Z first)
- `desc` - Descending (newest/Z-A first)

**limit** - Maximum posts (optional)
- Useful for "recent posts" lists
- No limit if omitted

**output_type** - Where to output (required)
- `file` - Generate standalone page
- `variable` - Create template variable

**output_suffix** - File extension override (optional)
- Default uses protocol suffix (html/gmi)
- Use `xml` for feeds and sitemaps

**output_path** - Custom output path (optional)
- Overrides default taxonomy-based path
- Example: `sitemap.xml` for root-level file

## Value Indexes

Configure how taxonomy value lists are generated:

```json
{
  "id": "index",
  "template": "tags-index",
  "item_template": "tags-index-item",
  "order_by": "name",
  "order_direction": "asc",
  "output_type": "file",
  "inlined_index_id": "index_by_value"
}
```

Most fields same as value_posts_indexes, plus:

**order_by** - Sort method
- `name` - Alphabetically by value name
- `count` - By number of posts

**inlined_index_id** - Embed posts index (optional)
- References another index by id
- Shows posts under each taxonomy value
- Creates combined index pages

## Real-World Examples

### RSS Feed Configuration

```json
{
  "id": "feed",
  "template": "rss-feed",
  "item_template": "rss-item",
  "order_by": "date",
  "order_direction": "desc",
  "output_type": "file",
  "output_suffix": "xml"
}
```

Generates: `/blog/feed.xml`

### Recent Posts Widget

```json
{
  "id": "recent-posts",
  "template": "recent-posts-list",
  "item_template": "recent-posts-item",
  "order_by": "date",
  "order_direction": "desc",
  "limit": "5",
  "output_type": "variable"
}
```

Creates variable: `{{ blog_recent-posts_ }}`

### Tag Index with Posts

```json
{
  "id": "index",
  "template": "tags-index",
  "item_template": "tags-index-item",
  "order_by": "name",
  "output_type": "file",
  "inlined_index_id": "index_by_value"
}
```

Shows all tags, with posts under each tag.

## Tips

1. Start with the --init example configuration
2. Modify one taxonomy at a time
3. Check console for generated variable names
4. Use descriptive id names
5. Test both file and variable outputs

Configuration is powerful but straightforward once you understand the structure!
