<!-- date: 2024-01-03 -->
<!-- title: Templates and Variables Guide -->
<!-- blog -->
<!-- tags: Tutorial, Templates -->
<!-- series: Documentation -->
<!-- readtime: 7 -->

Picogen's template system uses simple `{{ variable }}` placeholders that get replaced during generation. This guide covers everything you need to know about templates and variables.

## Template Syntax

Variables are enclosed in double curly braces:

```html
<h1>{{ title }}</h1>
<div>Published: {{ date }}</div>
<div>{{ body }}</div>
```

During generation, these placeholders are replaced with actual content.

## Template Inheritance

Templates support single-level inheritance using underscore naming:

**Naming convention:** `child_parent.html`

The child content replaces `{{ body }}` in the parent.

**Example:**

`page.html` (parent):
```html
<!DOCTYPE html>
<html>
  <head><title>{{ title }}</title></head>
  <body>
    <nav>...</nav>
    {{ body }}
    <footer>...</footer>
  </body>
</html>
```

`post_page.html` (child):
```html
<article>
  <h1>{{ title }}</h1>
  <div>{{ date }} | {{ readtime }} minutes</div>
  {{ body }}
</article>
```

In config, reference it as `"template": "post"` - Picogen automatically merges them.

## System Variables

Available everywhere:

- `{{ scheme }}` - URL scheme (http, https, gemini)
- `{{ domain }}` - Site domain
- `{{ base_path }}` - Base path for URLs
- `{{ current_year }}` - Current year (for copyright)
- `{{ subtitle }}` - Site tagline
- `{{ author }}` - Author name

## Content Variables

From file metadata headers:

- `{{ title }}` - Post/page title
- `{{ date }}` - Publication date
- `{{ body }}` - Converted content
- `{{ summary }}` - Auto-extracted first paragraph
- `{{ readtime }}` - Reading time in minutes
- `{{ relative_path }}` - URL to this page
- `{{ page_views }}` - View count (if tracking enabled)

## Custom Variables

Any metadata field becomes a variable:

```markdown
<!-- author_bio: Software developer and writer -->
<!-- custom_color: blue -->
```

Use them: `{{ author_bio }}` and `{{ custom_color }}`

## Generated Index Variables

Picogen generates index variables from taxonomy config:

**Format:** `{{ taxonomy_id_index_id }}`

Examples:
- `{{ blog_recent-posts_ }}` - Recent blog posts
- `{{ tags_simple-list }}` - Tag list
- `{{ series_index }}` - Series index

For specific taxonomy values:
`{{ tags_index_by_value_tutorial }}` - All "Tutorial" posts

## Taxonomy Template Variables

In taxonomy index templates:

- `{{ taxonomy_id }}` - Identifier (tags, series)
- `{{ taxonomy_title }}` - Display title
- `{{ taxonomy_value }}` - Current value (Tutorial)
- `{{ taxonomy_value_normalized }}` - URL-safe (tutorial)
- `{{ taxonomy_value_posts_count }}` - Post count
- `{{ taxonomy_value_posts_index }}` - Inlined posts

## Best Practices

1. **Use meaningful names** - Variable names should be self-documenting
2. **Check console output** - Generated variable names are logged during build
3. **Test with --init** - The demo site shows all variables in action
4. **Keep templates simple** - Easier to maintain and debug

The template system is powerful yet simple - perfect for creating maintainable static sites!
