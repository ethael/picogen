<!-- date: 2024-02-01 -->
<!-- title: Customizing Templates -->
<!-- blog: -->
<!-- tags: Tutorial, Design -->
<!-- series: Getting Started Guide -->
<!-- readtime: 4 -->

Templates in Picogen are simple yet powerful. They use a straightforward variable substitution syntax that's easy to understand and modify.

### Template Syntax

Templates use double curly braces for variables:

```
<h1>{{ title }}</h1>
<p>Published on {{ formatted_date }}</p>
```

Any metadata you define in your post becomes available as a template variable. This includes custom fields you create yourself.

### Template Inheritance

Picogen supports one level of template inheritance using underscores in filenames. A template named `post_page.html` will be merged with `page.html`, with the child template's body inserted into the parent.

This simple system is enough for most use cases while keeping complexity low.

### Available Variables

Picogen provides several built-in variables:

- `title`, `date`, `formatted_date`, `rfc3339_date`
- `body`, `summary` - The post content and excerpt
- `scheme`, `domain`, `base_path` - Site configuration
- `current_year`, `rfc3339_now` - Current date/time
- Any custom metadata you define

### Styling Your Site

CSS files go in the `static/html` directory and are copied to your output unchanged. The example site uses a dark monospace theme, but you can customize it however you like.

The template system is intentionally minimal - it does just enough to be useful without becoming a complex templating language.
