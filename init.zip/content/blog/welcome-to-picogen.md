<!-- date: 2024-01-15 -->
<!-- title: Welcome to Picogen -->
<!-- blog: -->
<!-- tags: Tutorial, Getting Started -->

Welcome to Picogen, a minimalistic static site generator written in a single Python file. This example blog post will show you how simple it is to create content with Picogen.

### What is Picogen?

Picogen is designed with simplicity in mind. Unlike complex static site generators with hundreds of dependencies, Picogen keeps everything in one file. You can read and understand the entire codebase in an afternoon.

### Key Features

- **Single file implementation** - The entire generator is in one Python file
- **Markdown support** - Write your content in Markdown format
- **Multiple protocols** - Generate both HTML and Gemini versions
- **Taxonomy system** - Organize content with tags, categories, series, etc.
- **RSS feeds** - Automatic feed generation for your content
- **Sitemap generation** - SEO-friendly sitemaps out of the box

### Getting Started

Creating a new post is as simple as creating a Markdown file in the `content/blog` directory. Add some metadata in HTML comments at the top, write your content, and run the generator.

That's all there is to it! Picogen will handle the rest.
