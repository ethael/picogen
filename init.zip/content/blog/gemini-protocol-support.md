<!-- date: 2024-02-10 -->
<!-- title: Gemini Protocol Support -->
<!-- blog: -->
<!-- tags: Gemini, Tutorial -->

Picogen can generate content for both HTTP and the Gemini protocol. This makes it easy to maintain a presence in both the traditional web and the growing Gemini space.

### What is Gemini?

Gemini is a new internet protocol that sits between Gopher and HTTP. It's designed to be simple, privacy-respecting, and focused on content over complexity. No JavaScript, no tracking, no complex markup - just clean, readable content.

### Dual Protocol Generation

With Picogen, you write your content once in Markdown, and it gets converted to both HTML and Gemtext (Gemini's markup format). The same content, optimized for each protocol.

To generate both versions:

```
python picogen.py --generate html gemini
```

### Serving Gemini Content

Picogen includes built-in server support for testing:

```
python picogen.py --serve gemini --port 1965
```

For production, you can use any Gemini server software pointed at the `target/gmi` directory.

### Template Differences

You'll notice separate template directories for HTML and Gemini. While the content is the same, each protocol has its own presentation style. HTML templates are full HTML documents, while Gemini templates use simple text formatting.

### Why Support Gemini?

The Gemini community values simplicity, privacy, and independence from big tech. If these values resonate with you, Picogen makes it trivial to participate in this alternative internet space while maintaining your traditional website.
