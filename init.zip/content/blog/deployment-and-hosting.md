<!-- date: 2024-02-15 -->
<!-- title: Deployment and Hosting -->
<!-- blog: -->
<!-- tags: Tutorial, Deployment -->

Once you've generated your static site with Picogen, deploying it is straightforward. Since the output is pure static HTML, you have many hosting options.

### GitHub Pages

The simplest option is GitHub Pages. Just push your `target/html` directory to a GitHub repository configured for Pages, and you're live. It's free, fast, and integrates well with git-based workflows.

### Traditional Web Hosting

Any web server can host Picogen's output. Upload the contents of `target/html` to your server via FTP, SFTP, or rsync. Point your web server's document root at it, and you're done.

### Modern Static Hosting

Services like Netlify, Vercel, or Cloudflare Pages work great with Picogen. They offer features like:

- Automatic deployments from git
- Free SSL certificates
- CDN distribution
- Custom domains

### Self-Hosting

If you prefer full control, running your own web server is easy. The example includes a simple HTTP server for local testing:

```
python picogen.py --serve http
```

For production, use nginx, Apache, or any other web server. Picogen's output is just static files - any HTTP server can handle it.

### RSS and Sitemap

Don't forget that Picogen generates RSS feeds and sitemaps automatically. Make sure these are accessible at the root of your site for search engines and feed readers to find them.

### Continuous Deployment

For the ultimate setup, configure your hosting to regenerate the site whenever you push changes to your content repository. Write a post, commit it, and moments later it's live on your site.
