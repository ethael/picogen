<!-- date: 2024-01-06 -->
<!-- title: RSS Feeds and Sitemap Generation -->
<!-- blog: -->
<!-- tags: SEO, RSS, Configuration -->
<!-- series: Documentation -->
<!-- readtime: 6 -->

Picogen automatically generates RSS/Atom feeds and XML sitemaps for your site. This guide shows you how to configure and use these features.

## RSS/Atom Feeds

RSS feeds let readers subscribe to your content through feed readers like Feedly, NewsBlur, or Thunderbird.

### Configuration

Feeds are configured as a `value_posts_index` with XML output:

```json
{
  "taxonomies": [
    {
      "id": "blog",
      "value_posts_indexes": [
        {
          "id": "feed",
          "template": "rss-feed",
          "item_template": "rss-item",
          "order_by": "date",
          "order_direction": "desc",
          "output_type": "file",
          "output_suffix": "xml"
        }
      ]
    }
  ]
}
```

This generates: `/blog/feed.xml`

### Feed Templates

Create two templates:

**templates/html/rss-feed.xml** - Feed wrapper:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>{{ subtitle }} - {{ taxonomy_title }}</title>
  <link href="{{ scheme }}://{{ domain }}{{ base_path }}" />
  <updated>{{ rfc3339_now }}</updated>
  <author><name>{{ author }}</name></author>
  {{ body }}
</feed>
```

**templates/html/rss-item.xml** - Individual entries:
```xml
<entry>
  <title>{{ title }}</title>
  <link href="{{ scheme }}://{{ domain }}{{ relative_dir_path }}/" />
  <id>{{ scheme }}://{{ domain }}{{ relative_dir_path }}/</id>
  <updated>{{ rfc3339_date }}</updated>
  <summary>{{ summary }}</summary>
</entry>
```

### Variables for Feeds

Important variables:

- `{{ rfc3339_now }}` - Current timestamp
- `{{ rfc3339_date }}` - Post publication date
- `{{ scheme }}` - Protocol (http/https/gemini)
- `{{ domain }}` - Your domain
- `{{ summary }}` - Auto-extracted first paragraph

### Linking to Feed

Add feed link in your page template:

```html
<head>
  <link rel="alternate" type="application/rss+xml"
        title="Blog Feed"
        href="{{ base_path }}blog/feed.xml"/>
</head>

<footer>
  <a href="{{ base_path }}blog/feed.xml">RSS</a>
</footer>
```

## XML Sitemap

Sitemaps help search engines discover and index your content. They're essential for SEO.

### Configuration

Configure as a `value_posts_index` with custom output path:

```json
{
  "taxonomies": [
    {
      "id": "blog",
      "value_posts_indexes": [
        {
          "id": "sitemap",
          "template": "sitemap",
          "item_template": "sitemap-item",
          "order_by": "date",
          "order_direction": "desc",
          "output_type": "file",
          "output_suffix": "xml",
          "output_path": "sitemap.xml"
        }
      ]
    }
  ]
}
```

The `output_path: "sitemap.xml"` generates the file at root instead of `/blog/sitemap.xml`.

This creates: `/sitemap.xml`

### Sitemap Templates

**templates/html/sitemap.xml** - Sitemap wrapper:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{{ body }}
</urlset>
```

**templates/html/sitemap-item.xml** - URL entries:
```xml
<url>
  <loc>{{ scheme }}://{{ domain }}{{ relative_dir_path }}/</loc>
  <lastmod>{{ rfc3339_date }}</lastmod>
</url>
```

### Robots.txt

Create `static/html/robots.txt` to reference your sitemap:

```
User-agent: *
Allow: /

Sitemap: https://yourdomain.com/sitemap.xml
```

Update domain and protocol (http/https) appropriately.

### Submitting Sitemap

Submit your sitemap to search engines:

- **Google Search Console**: https://search.google.com/search-console
- **Bing Webmaster Tools**: https://www.bing.com/webmasters
- **Yandex Webmaster**: https://webmaster.yandex.com

## Gemini Protocol

Generate feeds for Gemini too! The same configuration works:

**templates/gmi/rss-feed.xml** and **rss-item.xml**

Gemini feed is served at: `gemini://yourdomain/blog/feed.xml`

Most Gemini browsers support Atom feeds for subscriptions.

## Best Practices

### Feed Optimization

1. **Limit items** - Use `"limit": "50"` to keep feed size reasonable
2. **Good summaries** - Ensure first paragraph is descriptive
3. **Complete URLs** - Always use `{{ scheme }}://{{ domain }}{{ path }}`
4. **Update dates** - Use `rfc3339_date` for proper timestamps

### Sitemap Optimization

1. **Root location** - Always use `output_path: "sitemap.xml"`
2. **All content** - Include all public pages
3. **Correct dates** - Use post modification dates
4. **HTTPS** - Set `ssl_enabled: "true"` if using HTTPS

### Testing

- **Validate feed**: https://validator.w3.org/feed/
- **Validate sitemap**: https://www.xml-sitemaps.com/validate-xml-sitemap.html
- **Test in reader**: Try your feed in Feedly or similar

## Troubleshooting

**Feed not validating?**
- Check XML syntax (no unclosed tags)
- Ensure `{{ body }}` placeholder exists
- Validate URLs are complete with scheme + domain

**Sitemap not found?**
- Verify `output_path` is set
- Check file is at root: `/sitemap.xml`
- Ensure robots.txt points to correct URL

**Missing posts in feed?**
- Check order_by and order_direction
- Verify posts have date metadata
- Look for draft flag in posts

Feeds and sitemaps are essential for reaching readers and search engines - configure them once and forget about them!
