<!-- date: 2024-01-02 -->
<!-- title: Understanding the Taxonomy System -->
<!-- blog: -->
<!-- tags: Tutorial, Advanced -->
<!-- series: Documentation -->
<!-- readtime: 6 -->

The taxonomy system is one of Picogen's most powerful features. It provides a flexible way to organize and categorize your content.

## What is Taxonomy?

Taxonomy means categorization or classification. Common examples include:

- **Blog** - Marks content as blog posts
- **Tags** - Topical keywords (Tutorial, Python, Web)
- **Series** - Multi-part article series
- **Categories** - Broader content groupings

You can define any taxonomy you want - Picogen doesn't restrict you to predefined types.

## Declaring Taxonomies

Add taxonomies to your content files using HTML comment metadata:

```markdown
<!-- blog: -->
<!-- tags: Tutorial, Advanced -->
<!-- series: Getting Started Guide -->
```

Values can be:
- Empty (just marks the taxonomy applies)
- Single value
- Comma-separated list of values

## Two Types of Indexes

Picogen generates two types of indexes for each taxonomy:

### 1. Taxonomy Value Posts Index (TVPI)

Lists all posts that belong to a specific taxonomy value.

**Example:** A page showing all posts tagged "Tutorial"
**URL:** `/tags/tutorial/index.html`

### 2. Taxonomy Value Index (TVI)

Lists all values of a taxonomy with post counts.

**Example:** A page listing all available tags
**URL:** `/tags/index.html`

## Configuration

Taxonomies are configured in `config.json`:

```json
{
  "taxonomies": [
    {
      "id": "tags",
      "title": "Tags",
      "value_posts_indexes": [
        {
          "id": "index",
          "template": "blog-index",
          "item_template": "blog-index-item",
          "output_type": "file"
        }
      ],
      "value_indexes": [
        {
          "id": "index",
          "template": "tags-index",
          "item_template": "tags-index-item",
          "output_type": "file"
        }
      ]
    }
  ]
}
```

## File vs Variable Output

Indexes can be generated as:

- **file** - Creates a standalone page
- **variable** - Generates content that can be embedded in other pages

Variable output is perfect for sidebars, footers, or inline lists. File output creates dedicated index pages.

## Automatic Features

Picogen automatically:
- Creates URL-safe slugs from taxonomy values (spaces become hyphens)
- Sorts indexes by date, name, or post count
- Counts posts per taxonomy value
- Generates navigation between related posts

The taxonomy system makes it easy to create rich, organized sites without manual index maintenance!
