<!-- date: 2024-01-08 -->
<!-- title: Deploying Your Picogen Site -->
<!-- blog: -->
<!-- tags: Deployment, Hosting, Tutorial -->
<!-- series: Documentation -->
<!-- readtime: 6 -->

After generating your site, it's time to deploy it. Since Picogen creates static files, you have many hosting options. This guide covers the most popular choices.

## Static Site Hosting

Picogen generates static files in `target/html/` and `target/gmi/` - no server-side processing needed. This makes hosting simple and cheap (often free).

## Popular Hosting Options

### GitHub Pages

**Pros:** Free, custom domains, HTTPS, git-based
**Cons:** Public repositories only (unless paid)

**Steps:**
1. Create repository: `username.github.io`
2. Generate site: `python picogen.py --generate http`
3. Copy `target/html/*` to repository root
4. Commit and push

Your site appears at: `https://username.github.io`

**Custom domain:** Add `CNAME` file with your domain.

### Netlify

**Pros:** Free tier, automatic builds, CDN, custom domains
**Cons:** Build limits on free tier

**Steps:**
1. Push your Picogen project to Git
2. Connect repository to Netlify
3. Build command: `python picogen.py --generate http`
4. Publish directory: `target/html`
5. Deploy

Netlify auto-rebuilds on git push!

### Cloudflare Pages

**Pros:** Free, fast CDN, unlimited bandwidth
**Cons:** Build time limits

Similar to Netlify:
1. Connect git repository
2. Build command: `python picogen.py --generate http`
3. Output directory: `target/html`

### Traditional Web Hosting

Any web host supporting static files works:

**Via FTP/SFTP:**
1. Generate: `python picogen.py --generate http`
2. Upload `target/html/*` to public_html/
3. Done!

**Popular hosts:**
- Nearly Free Speech (NFS)
- DreamHost
- HostGator
- Any shared hosting

### Amazon S3 + CloudFront

**Pros:** Scalable, cheap, CDN
**Cons:** Requires AWS knowledge

**Steps:**
1. Create S3 bucket (public)
2. Enable static website hosting
3. Upload `target/html/*`
4. Optional: Add CloudFront for CDN + HTTPS

## Gemini Protocol Hosting

For `target/gmi/` content:

### Gemini-Specific Hosts

Free Gemini hosting:
- **Flounder** - https://flounder.online
- **Gemlog.blue** - https://gemlog.blue

### Self-Hosting Gemini

Run your own Gemini server:

**Using Agate:**
```bash
# Install agate
cargo install agate

# Generate TLS certificate
openssl req -x509 -newkey rsa:4096 -nodes \
  -keyout key.pem -out cert.pem -days 365 \
  -subj "/CN=yourdomain.com"

# Serve
agate --content target/gmi/ --hostname yourdomain.com
```

**Using Jetforce:**
```bash
pip install jetforce

python picogen.py --serve gemini --port 1965
```

Point domain to your server on port 1965.

## Configuration for Deployment

Update `config.json` before deploying:

```json
{
  "domain": "yourdomain.com",
  "ssl_enabled": "true",
  "base_path": "/",
  "generator_url": "https://github.com/yourusername/your-site"
}
```

Critical fields:
- `domain` - Your actual domain
- `ssl_enabled` - "true" for HTTPS sites
- `base_path` - "/" unless in subdirectory

## Build Workflow

### Local Development

```bash
# Generate and test
python picogen.py --generate http gemini
python picogen.py --serve http

# Make changes, regenerate
python picogen.py --generate http gemini
```

### Production Build

```bash
# Clean build
rm -rf target/
python picogen.py --generate http gemini

# Deploy target/html/ to web host
# Deploy target/gmi/ to Gemini host
```

## Automation

### Git Hook

Auto-deploy on push with git hook:

**.git/hooks/post-commit:**
```bash
#!/bin/bash
python picogen.py --generate http
rsync -av target/html/ user@host:/var/www/
```

Make executable: `chmod +x .git/hooks/post-commit`

### Shell Script

**deploy.sh:**
```bash
#!/bin/bash
echo "Building site..."
python picogen.py --generate http gemini

echo "Deploying HTML..."
rsync -av --delete target/html/ user@host:/var/www/html/

echo "Deploying Gemini..."
rsync -av --delete target/gmi/ user@host:/srv/gemini/

echo "Done!"
```

### Makefile

**Makefile:**
```makefile
.PHONY: build serve deploy

build:
	python picogen.py --generate http gemini

serve:
	python picogen.py --serve http

deploy: build
	rsync -av --delete target/html/ user@host:/var/www/
```

Usage: `make deploy`

## Performance Tips

1. **Optimize images** - Compress before adding to static/
2. **Minify CSS** - Reduce file sizes
3. **Enable caching** - Configure host caching headers
4. **Use CDN** - Cloudflare, CloudFront, etc.
5. **Compress files** - Enable gzip on server

## Security Considerations

1. **HTTPS** - Always use SSL for HTTP sites
2. **Don't commit secrets** - Add sensitive files to .gitignore
3. **Validate feeds** - Ensure no XSS in content
4. **Check robots.txt** - Verify sitemap URL is correct

## Testing Before Deploy

Always test generated output:

```bash
# Generate
python picogen.py --generate http gemini

# Test locally
python picogen.py --serve http
python picogen.py --serve gemini --port 8001

# Check all pages work
# Verify links and images
# Test RSS feed
# Validate sitemap
```

## Continuous Deployment Example

Full workflow with GitHub Actions:

**.github/workflows/deploy.yml:**
```yaml
name: Deploy Site

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
      - run: pip install Unidecode beautifulsoup4 md2gemini commonmark
      - run: python picogen.py --generate http
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./target/html
```

This auto-deploys to GitHub Pages on every push!

## Troubleshooting

**Links broken after deploy?**
- Check `base_path` in config.json
- Verify all URLs use `{{ base_path }}`

**Images not loading?**
- Ensure images are in `static/html/`
- Check image paths in templates

**RSS feed not working?**
- Verify `domain` and `ssl_enabled` correct
- Check feed uses absolute URLs

Deployment is straightforward with static files - choose a host and upload. That's it!
