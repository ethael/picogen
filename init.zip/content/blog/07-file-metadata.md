<!-- date: 2024-01-07 -->
<!-- title: File Metadata and Headers -->
<!-- blog -->
<!-- tags: Tutorial, Reference -->
<!-- series: Documentation -->
<!-- readtime: 5 -->

Content files in Picogen start with metadata headers using HTML comments. This guide covers all metadata options and best practices.

## Basic Format

Metadata appears at the top of content files:

```markdown
<!-- date: 2024-01-15 -->
<!-- title: My Post Title -->
<!-- blog -->

# Post Content Starts Here

Your actual content begins after the metadata section...
```

Each metadata field uses HTML comment syntax: `<!-- field: value -->`

## Standard Fields

### date

Publication date in YYYY-MM-DD format:

```markdown
<!-- date: 2024-01-15 -->
```

- Optional (defaults to 1970-01-01)
- Used for sorting posts
- Converted to various formats available as variables
- Format: ISO 8601 date (YYYY-MM-DD)

### title

Post or page title:

```markdown
<!-- title: Getting Started with Picogen -->
```

- Optional but recommended
- Used in templates as `{{ title }}`
- Appears in feeds, sitemaps, and page headers
- Can include spaces and special characters

### template

Override default template:

```markdown
<!-- template: custom-layout -->
```

- Optional
- Overrides taxonomy `document_template`
- Refers to template name without extension
- Example: `custom-layout` looks for `custom-layout_page.html`

### draft

Mark content as draft to skip during generation:

```markdown
<!-- draft: -->
```

- Optional
- Value doesn't matter - presence marks as draft
- Completely excludes file from build
- Perfect for work-in-progress posts

## Taxonomy Fields

Any taxonomy defined in config.json can be used as metadata.

### Single Value

```markdown
<!-- category: Technology -->
```

### Multiple Values

Comma-separated list:

```markdown
<!-- tags: Python, Tutorial, Web Development -->
```

### Empty Value

Just marks taxonomy applies:

```markdown
<!-- blog -->
```

Common for taxonomies that don't need values (just marking something as a blog post).

## Custom Fields

**Any field becomes a template variable!**

```markdown
<!-- author_bio: Software developer and writer -->
<!-- reading_level: Intermediate -->
<!-- custom_color: blue -->
<!-- github_repo: https://github.com/user/repo -->
```

Use in templates:
- `{{ author_bio }}`
- `{{ reading_level }}`
- `{{ custom_color }}`
- `{{ github_repo }}`

## Real-World Example

Complete blog post header:

```markdown
<!-- date: 2024-01-15 -->
<!-- title: Building Scalable APIs -->
<!-- blog -->
<!-- tags: API, Python, Architecture -->
<!-- series: Backend Development -->
<!-- readtime: 8 -->
<!-- difficulty: Advanced -->
<!-- github_repo: https://github.com/example/api -->

# Building Scalable APIs

Your post content here...
```

This creates variables for all fields, making them available in templates.

## Generated Variables

From metadata, Picogen creates:

**Direct variables:**
- `{{ date }}` - Original date (2024-01-15)
- `{{ title }}` - Post title
- `{{ readtime }}` - Reading time

**Computed variables:**
- `{{ rfc3339_date }}` - RFC3339 timestamp for feeds
- `{{ formatted_date }}` - Custom formatted (if `custom_date_format` in config)
- `{{ summary }}` - Auto-extracted first paragraph
- `{{ file_name }}` - Filename without extension

## Best Practices

### Required Metadata

Always include:
```markdown
<!-- date: YYYY-MM-DD -->
<!-- title: Descriptive Title -->
```

### Consistent Taxonomy Values

Use consistent naming:
- ✅ "Getting Started"
- ❌ "getting-started", "Getting started", "GettingStarted"

Picogen normalizes for URLs, but consistency helps organization.

### Reading Time

Estimate honestly:
```markdown
<!-- readtime: 5 -->
```

Average reading speed: ~200-250 words per minute.

### Descriptive Titles

Good titles help with:
- SEO
- Feed readers
- Navigation
- Social sharing

### Optional Metadata

Add custom fields as needed:
- `author` - Per-post author override
- `thumbnail` - Featured image path
- `canonical_url` - Original source if republished
- `updated` - Last update date

## URL Generation

Metadata affects URL structure:

**Filename:** `getting-started.md`
**Title:** `Getting Started with Picogen`
**URL:** `/blog/getting-started/index.html`

URLs use filename, not title. Choose descriptive filenames!

## Troubleshooting

**Post not appearing?**
- Check for `<!-- draft: -->` field
- Verify file extension (.md, .html, or .gmi)
- Ensure taxonomy matches config

**Wrong template used?**
- Check `template` field spelling
- Verify template file exists
- Check taxonomy `document_template`

**Variables not working?**
- Ensure format: `<!-- field: value -->`
- No spaces before `<!--`
- Check template uses correct variable name

**Special characters in values?**
- Avoid quotes in values
- Use plain text
- HTML entities not needed

Metadata is powerful and flexible - use it to make your content rich and well-organized!
