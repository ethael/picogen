<!-- date: 2024-01-09 -->
<!-- title: Advanced Features and Techniques -->
<!-- blog -->
<!-- tags: Advanced, Tips, Tutorial -->
<!-- series: Documentation -->
<!-- readtime: 7 -->

Once you master the basics, Picogen offers advanced features for power users. This guide covers URL normalization, custom variables, page view tracking, and more.

## URL Normalization

Picogen automatically creates URL-safe strings from taxonomy values.

### The normalize_string() Function

Converts any string to URL-safe format:

1. Removes accents: `Café` → `Cafe`
2. Converts spaces to hyphens: `Getting Started` → `getting-started`
3. Lowercases: `Tutorial` → `tutorial`

### Using in Templates

Use `{{ taxonomy_value_normalized }}` for links:

```
=> {{ base_path }}{{ taxonomy_id }}/{{ taxonomy_value_normalized }}/index.gmi {{ taxonomy_value }}
```

This ensures URLs work correctly even with spaces or accents in taxonomy values.

**Example:**
- Value: "Getting Started Guide"
- URL: `/series/getting-started-guide/`
- Display: "Getting Started Guide"

### Why It Matters

Without normalization, spaces in URLs break in Gemini browsers and cause issues in HTML.

Always use:
- `{{ taxonomy_value_normalized }}` - For URLs
- `{{ taxonomy_value }}` - For display text

## Page View Tracking

Track page popularity with external analytics data.

### Setup

1. Create views file (`views.txt`):
```
/blog/popular-post:1523
/blog/another-post:847
/projects:234
/:5829
```

Format: `path:count` (one per line)

2. Configure in `config.json`:
```json
{
  "page_views_file": "views.txt"
}
```

3. Use in templates:
```html
<div>{{ page_views }} views</div>
```

### Generating View Counts

Use server logs or analytics:

```bash
# From nginx logs
awk '{print $7}' access.log | sort | uniq -c | \
  awk '{print $2":"$1}' > views.txt
```

Or export from Google Analytics, Matomo, etc.

## Custom Date Formatting

Control how dates appear in your site.

### Configuration

In `config.json`:
```json
{
  "custom_date_format": "%B %d, %Y"
}
```

This creates `{{ formatted_date }}` variable.

### Format Codes

Common Python strftime codes:

- `%Y` - Year (2024)
- `%m` - Month number (01)
- `%d` - Day (15)
- `%B` - Full month (January)
- `%b` - Short month (Jan)
- `%A` - Full weekday (Monday)
- `%a` - Short weekday (Mon)

**Examples:**
- `%B %d, %Y` → "January 15, 2024"
- `%Y-%m-%d` → "2024-01-15"
- `%d %b %Y` → "15 Jan 2024"
- `%A, %B %d` → "Monday, January 15"

## Custom Variables in Config

Add custom variables to index templates.

### Configuration

```json
{
  "id": "feed",
  "template": "rss-feed",
  "item_template": "rss-item",
  "output_type": "file",
  "custom_variables": {
    "feed_description": "Latest blog posts",
    "feed_category": "Technology",
    "feed_url": "{{ scheme }}://{{ domain }}{{ base_path }}blog/feed.xml"
  }
}
```

### Usage

In `rss-feed.xml`:
```xml
<subtitle>{{ feed_description }}</subtitle>
<category>{{ feed_category }}</category>
<link href="{{ feed_url }}" rel="self" />
```

Custom variables support variable interpolation - you can use `{{ scheme }}`, `{{ domain }}`, etc. in their values!

## Inlined Indexes

Combine taxonomy value lists with post lists.

### Configuration

```json
{
  "value_posts_indexes": [
    {
      "id": "index_by_value",
      "template": "tag-posts",
      "item_template": "tag-post-item",
      "output_type": "variable"
    }
  ],
  "value_indexes": [
    {
      "id": "index",
      "template": "tags-index",
      "item_template": "tags-index-item",
      "output_type": "file",
      "inlined_index_id": "index_by_value"
    }
  ]
}
```

The `inlined_index_id` references another index to embed.

### Result

Creates a page showing:
- List of all tags
- Under each tag, all posts with that tag

Use `{{ taxonomy_value_posts_index }}` in item template to show the inlined content.

## Multiple Index Types

Create different index views of the same taxonomy.

### Example: Blog Indexes

```json
{
  "id": "blog",
  "value_posts_indexes": [
    {
      "id": "index",
      "template": "blog-index",
      "output_type": "file"
    },
    {
      "id": "archive",
      "template": "blog-archive",
      "output_type": "file"
    },
    {
      "id": "recent-posts",
      "template": "recent-list",
      "limit": "5",
      "output_type": "variable"
    }
  ]
}
```

Creates:
- `/blog/index.html` - Full blog index
- `/blog/archive.html` - Archive view (different template)
- `{{ blog_recent-posts_ }}` - Recent posts widget

## Conditional Content

Use custom metadata for conditional display.

### In Content File

```markdown
<!-- featured: true -->
<!-- premium: true -->
```

### In Template

```html
{{ featured }}
{{ premium }}
```

Variables contain the values - use them to show/hide content or apply CSS classes.

## Working with Summary

Picogen auto-generates `{{ summary }}` from first paragraph.

### HTML

Extracts first `<p>` tag content.

### Gemini

Extracts first paragraph (text until blank line).

### Tips

- Make first paragraph compelling
- Keep it concise (1-2 sentences)
- Avoid markdown in first paragraph for clean summaries
- Use for feed descriptions and meta tags

## Protocol-Specific Templates

Create different experiences per protocol.

**templates/html/post_page.html:**
```html
<article class="blog-post">
  <h1>{{ title }}</h1>
  <div class="meta">
    {{ date }} | {{ readtime }} min
    <span class="views">{{ page_views }} views</span>
  </div>
  {{ body }}
  <div class="tags">{{ tags }}</div>
</article>
```

**templates/gmi/post_page.gmi:**
```
{{ title }}

{{ date }} | {{ readtime }} minutes

{{ body }}

Tags: {{ tags }}
```

Same content, optimized presentation for each protocol.

## Ordering and Limits

Fine-tune index generation.

### Order By Any Field

```json
{
  "order_by": "readtime",
  "order_direction": "asc"
}
```

Shows shortest posts first!

### Multiple Limits

```json
{
  "id": "short-posts",
  "limit": "3",
  "order_by": "readtime",
  "order_direction": "asc"
}
```

Creates "Quick reads" section with 3 shortest posts.

## Performance Optimization

### Limit Index Generation

Only generate needed indexes:
- Use `variable` for embedded content
- Use `file` only for standalone pages
- Set reasonable limits on large sites

### Efficient Templates

- Keep templates simple
- Avoid deep nesting
- Use clear variable names
- Comment complex logic

### Build Time

Typical build times:
- 10 posts: < 1 second
- 100 posts: 1-2 seconds
- 1000 posts: 5-10 seconds

Static generation scales well!

## Debugging

### Check Console Output

Generated variables are logged:
```
Generated blog_recent-posts_ taxonomy index variable
Generated tags_index_by_value_tutorial taxonomy index variable
```

Use these names in templates.

### Template Issues

- Variable not showing? Check spelling and underscores/hyphens
- Empty output? Verify index has correct output_type
- Wrong template? Check inheritance (underscore) vs multi-word (hyphen)

### Common Mistakes

1. Using `{{ taxonomy_value_lower }}` instead of `{{ taxonomy_value_normalized }}` for URLs
2. Forgetting `output_path` for root-level files
3. Wrong `output_suffix` for XML files
4. Missing parent template for inheritance

## Tips for Large Sites

1. **Organize content** - Use subdirectories in content/
2. **Limit indexes** - Don't generate every possible view
3. **Use drafts** - Work on posts without publishing
4. **Automate builds** - Use git hooks or CI/CD
5. **Test incrementally** - Generate and verify frequently

These advanced features make Picogen incredibly flexible while maintaining simplicity!
